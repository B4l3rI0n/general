let floatToggle = null;
let speedControllerBox = null;

function initVideoSpeedController() {
  if (document.querySelector('[data-video-controller="true"]')) return;

  // Toggle icon (floating and draggable)
  floatToggle = document.createElement("div");
  floatToggle.id = "videoSpeedToggle";
  Object.assign(floatToggle.style, {
    position: "fixed",
    top: "10px",
    right: "10px",
    width: "28px",
    height: "28px",
    background: "#1db954",
    color: "#fff",
    fontSize: "18px",
    fontWeight: "bold",
    textAlign: "center",
    lineHeight: "28px",
    borderRadius: "50%",
    zIndex: 10000,
    cursor: "move",
    userSelect: "none",
    boxShadow: "0 0 6px rgba(0,0,0,0.5)"
  });
  floatToggle.textContent = "▶";
  document.body.appendChild(floatToggle);

  // Controller box (relative to the icon)
  speedControllerBox = document.createElement("div");
  speedControllerBox.setAttribute("data-video-controller", "true");
  Object.assign(speedControllerBox.style, {
    position: "fixed",
    background: "#111",
    color: "#fff",
    padding: "12px",
    borderRadius: "10px",
    zIndex: 9999,
    fontFamily: "sans-serif",
    fontSize: "14px",
    boxShadow: "0 0 10px rgba(0,0,0,0.5)",
    minWidth: "200px",
    maxWidth: "300px",
    opacity: 0,
    transform: "scale(0.95)",
    transition: "opacity 0.3s ease, transform 0.3s ease",
    pointerEvents: "none" // initially hidden
  });

  const title = document.createElement("div");
  title.textContent = "🎬 Speed Controller";
  title.style.marginBottom = "8px";
  speedControllerBox.appendChild(title);

  const slider = document.createElement("input");
  slider.type = "range";
  slider.min = "0.1";
  slider.max = "10";
  slider.step = "0.1";
  slider.value = "1";
  Object.assign(slider.style, { width: "100%" });
  speedControllerBox.appendChild(slider);

  const display = document.createElement("div");
  display.textContent = `Speed: 1x`;
  display.style.marginTop = "6px";
  speedControllerBox.appendChild(display);

  const presetContainer = document.createElement("div");
  presetContainer.style.marginTop = "8px";
  presetContainer.style.display = "flex";
  presetContainer.style.flexWrap = "wrap";
  presetContainer.style.gap = "6px";
  [1, 1.5, 2, 3, 4].forEach(val => {
    const btn = document.createElement("button");
    btn.textContent = `${val}x`;
    btn.onclick = () => {
      slider.value = val;
      updateSpeed(val);
    };
    Object.assign(btn.style, {
      flex: "1 0 20%",
      minWidth: "40px",
      padding: "4px",
      fontSize: "12px",
      background: "#444",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer"
    });
    presetContainer.appendChild(btn);
  });
  speedControllerBox.appendChild(presetContainer);

  const autoWrapper = document.createElement("div");
  Object.assign(autoWrapper.style, {
    marginTop: "10px",
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    gap: "6px"
  });

  const autoBtn = document.createElement("button");
  autoBtn.textContent = "⏩ Auto-Speed";
  Object.assign(autoBtn.style, {
    background: "#2ecc71",
    color: "#fff",
    border: "none",
    padding: "6px",
    borderRadius: "5px",
    cursor: "pointer",
    flexGrow: 1,
    minWidth: "90px"
  });

  const autoMax = document.createElement("select");
  [1.5, 2, 3, 5, 10].forEach(val => {
    const opt = document.createElement("option");
    opt.value = val;
    opt.textContent = `${val}x`;
    autoMax.appendChild(opt);
  });
  autoMax.value = "2";
  Object.assign(autoMax.style, {
    padding: "4px",
    fontSize: "12px",
    borderRadius: "5px",
    flexShrink: 0,
    minWidth: "60px"
  });

  autoWrapper.appendChild(autoBtn);
  autoWrapper.appendChild(autoMax);
  speedControllerBox.appendChild(autoWrapper);
  document.body.appendChild(speedControllerBox);

  let autoMode = false;
  let autoInterval = null;

  autoBtn.onclick = () => {
    if (autoMode) {
      clearInterval(autoInterval);
      autoBtn.textContent = "⏩ Auto-Speed";
      autoMode = false;
    } else {
      autoMode = true;
      autoBtn.textContent = "⏸️ Stop Auto";
      let current = 1;
      const max = parseFloat(autoMax.value);
      slider.value = "1";
      updateSpeed("1");

      autoInterval = setInterval(() => {
        if (current < max) {
          current = Math.min(max, current + 0.05);
          slider.value = current.toFixed(2);
          updateSpeed(current);
        } else {
          clearInterval(autoInterval);
          autoBtn.textContent = "⏩ Auto-Speed";
          autoMode = false;
        }
      }, 3000);
    }
  };

  slider.oninput = () => updateSpeed(slider.value);

  function updateSpeed(speed) {
    document.querySelectorAll("video").forEach(v => v.playbackRate = parseFloat(speed));
    display.textContent = `Speed: ${parseFloat(speed).toFixed(2)}x`;
  }

  new MutationObserver(() => {
    document.querySelectorAll("video").forEach(v => v.playbackRate = parseFloat(slider.value));
  }).observe(document.body, { childList: true, subtree: true });

  document.addEventListener("keydown", e => {
    if (["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) return;
    if (e.key === "+" || e.key === "=") slider.stepUp();
    if (e.key === "-" || e.key === "_") slider.stepDown();
    if (e.key === "s" && floatToggle) floatToggle.click();
    updateSpeed(slider.value);
  });

floatToggle.onclick = () => {
  const visible = speedControllerBox.style.opacity === "1";
  if (visible) {
    speedControllerBox.style.opacity = "0";
    speedControllerBox.style.transform = "scale(0.95)";
    speedControllerBox.style.pointerEvents = "none";
  } else {
    const iconRect = floatToggle.getBoundingClientRect();
    const boxWidth = speedControllerBox.offsetWidth;

    speedControllerBox.style.top = `${iconRect.bottom + 8}px`;
    speedControllerBox.style.left = `${iconRect.right - boxWidth}px`;
    speedControllerBox.style.right = "auto";

    speedControllerBox.style.opacity = "1";
    speedControllerBox.style.transform = "scale(1)";
    speedControllerBox.style.pointerEvents = "auto";
  }
};


  floatToggle.onmousedown = function (e) {
    e.preventDefault();
    let shiftX = e.clientX - floatToggle.getBoundingClientRect().left;
    let shiftY = e.clientY - floatToggle.getBoundingClientRect().top;
    function moveAt(x, y) {
      floatToggle.style.left = x - shiftX + "px";
      floatToggle.style.top = y - shiftY + "px";
      floatToggle.style.right = "auto";
    }
    function onMouseMove(e) {
      moveAt(e.pageX, e.pageY);
    }
    document.addEventListener("mousemove", onMouseMove);
    document.onmouseup = () => document.removeEventListener("mousemove", onMouseMove);
  };
  floatToggle.ondragstart = () => false;
}

// Extension message handling
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.command === "toggleController") {
    if (floatToggle && floatToggle.isConnected) {
      floatToggle.remove();
      floatToggle = null;
    }
    if (speedControllerBox && speedControllerBox.isConnected) {
      speedControllerBox.remove();
      speedControllerBox = null;
    } else {
      initVideoSpeedController();
    }
  }
});
